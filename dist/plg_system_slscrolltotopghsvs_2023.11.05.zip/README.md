# plg_system_slscrolltotopghsvs

Joomla system plugin. Adds a scroll to top button in frontend and/or backend.

An adaption of plugin `System - Skyline Scroll To Top` by `Skyline Software` (http://extstore.com , Pham Minh Tuan) for Joomla 4.3+ and Joomla 5. By ghsvs.de.

```
/**
 * @copyright	Copyright (c) 2013 Skyline Software (http://extstore.com). All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 * @copyright	Edited by GHSVS 2023-11. Modifications by ghsvs.de will no longer reflect the original work of its authors.
 */
```
